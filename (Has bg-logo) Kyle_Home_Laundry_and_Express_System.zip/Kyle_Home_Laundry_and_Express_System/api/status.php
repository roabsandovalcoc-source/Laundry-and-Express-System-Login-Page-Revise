<?php
/**
 * Status API — Kyle Home Laundry and Express System
 * Handles: get_kanban, update_status
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/auth_middleware.php';
requireRole(ROLE_WASHER_FOLDER);

$pdo = getDBConnection();

$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'get_kanban') {
    try {
        $stmt = $pdo->query("
            SELECT o.*, c.FullName as CustomerName 
            FROM orders o 
            JOIN customers c ON o.CustomerID = c.CustomerID 
            WHERE o.Status IN ('Pending', 'Washing', 'Drying', 'Folding and Packing', 'Ready') 
            ORDER BY o.ReceivedAt ASC
        ");
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $servicesStmt = $pdo->query("
            SELECT osl.OrderID, st.ServiceName 
            FROM order_service_lines osl 
            JOIN service_types st ON osl.ServiceTypeID = st.ServiceTypeID
        ");
        $services = $servicesStmt->fetchAll(PDO::FETCH_ASSOC);

        $orderServices = [];
        foreach ($services as $s) {
            $orderServices[$s['OrderID']][] = $s['ServiceName'];
        }

        $kanban = [
            'Pending' => [],
            'Washing' => [],
            'Drying' => [],
            'Folding and Packing' => [],
            'Ready' => []
        ];

        foreach ($orders as $order) {
            $order['Services'] = implode(', ', $orderServices[$order['OrderID']] ?? []);
            if (isset($kanban[$order['Status']])) {
                $kanban[$order['Status']][] = $order;
            }
        }

        echo json_encode(['success' => true, 'data' => $kanban]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update_status') {
    $orderId = $_POST['order_id'] ?? null;
    $newStatus = $_POST['new_status'] ?? null;
    $machineNumber = $_POST['machine_number'] ?? null;
    $userId = $_SESSION['user_id'];

    if (!$orderId || !$newStatus) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit;
    }

    $validProgressions = [
        'Pending' => 'Washing',
        'Washing' => 'Drying',
        'Drying' => 'Folding and Packing',
        'Folding and Packing' => 'Ready'
    ];

    try {
        $stmt = $pdo->prepare("SELECT Status FROM orders WHERE OrderID = ?");
        $stmt->execute([$orderId]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$order) {
            echo json_encode(['success' => false, 'message' => 'Order not found']);
            exit;
        }

        $currentStatus = $order['Status'];

        if (!isset($validProgressions[$currentStatus]) || $validProgressions[$currentStatus] !== $newStatus) {
            echo json_encode(['success' => false, 'message' => 'Invalid status progression']);
            exit;
        }

        $updateQuery = "UPDATE orders SET Status = ?, LastUpdatedByUserID = ?, LastUpdatedAt = NOW()";
        $params = [$newStatus, $userId];

        if ($machineNumber !== null && ($newStatus === 'Washing' || $newStatus === 'Drying')) {
            $updateQuery .= ", MachineNumber = ?";
            $params[] = $machineNumber;
        }

        $updateQuery .= " WHERE OrderID = ?";
        $params[] = $orderId;

        $pdo->beginTransaction();

        $updateStmt = $pdo->prepare($updateQuery);
        $updateStmt->execute($params);

        writeAuditLog($pdo, $userId, $orderId, 'Status Update', $currentStatus, $newStatus, "Moved from $currentStatus to $newStatus");

        $pdo->commit();

        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
