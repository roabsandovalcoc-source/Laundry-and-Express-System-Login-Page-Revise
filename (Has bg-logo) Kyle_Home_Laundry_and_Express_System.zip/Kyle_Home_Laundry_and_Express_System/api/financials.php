<?php
/**
 * Financials API — Kyle Home Laundry and Express System
 * Handles: daily_summary, audit_log
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/auth_middleware.php';

requireRole([ROLE_MANAGER]);

$pdo = getDBConnection();

$action = $_GET['action'] ?? '';

if ($action === 'daily_summary') {
    $date = $_GET['date'] ?? date('Y-m-d');
    
    try {
        // Total revenue
        $stmt = $pdo->prepare("SELECT 
            COALESCE(SUM(TotalAmount), 0) as total_revenue,
            COUNT(*) as total_orders,
            SUM(CASE WHEN IsDelivery = 1 THEN 1 ELSE 0 END) as delivery_orders,
            SUM(CASE WHEN IsDelivery = 0 THEN 1 ELSE 0 END) as walkin_orders
            FROM orders 
            WHERE Status IN (?, ?) AND DATE(CompletedAt) = ?");
        $stmt->execute([STATUS_DELIVERED, STATUS_PICKED_UP, $date]);
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);

        // Staff breakdown
        $stmt = $pdo->prepare("SELECT 
            u.FullName,
            COUNT(o.OrderID) as orders_completed,
            COALESCE(SUM(o.TotalAmount), 0) as revenue
            FROM orders o
            JOIN users u ON o.LastUpdatedByUserID = u.UserID
            WHERE o.Status IN (?, ?) AND DATE(o.CompletedAt) = ?
            GROUP BY u.UserID, u.FullName
            ORDER BY revenue DESC");
        $stmt->execute([STATUS_DELIVERED, STATUS_PICKED_UP, $date]);
        $staff_breakdown = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Orders list
        $stmt = $pdo->prepare("SELECT 
            o.OrderNumber,
            c.FullName as CustomerName,
            o.TotalAmount,
            o.Status,
            o.CompletedAt,
            u.FullName as StaffName,
            o.IsDelivery,
            (SELECT GROUP_CONCAT(st.ServiceName SEPARATOR ', ') 
             FROM order_service_lines osl 
             JOIN service_types st ON osl.ServiceTypeID = st.ServiceTypeID 
             WHERE osl.OrderID = o.OrderID) as Services
            FROM orders o
            JOIN customers c ON o.CustomerID = c.CustomerID
            LEFT JOIN users u ON o.LastUpdatedByUserID = u.UserID
            WHERE o.Status IN (?, ?) AND DATE(o.CompletedAt) = ?
            ORDER BY o.CompletedAt DESC");
        $stmt->execute([STATUS_DELIVERED, STATUS_PICKED_UP, $date]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'status' => 'success',
            'data' => [
                'stats' => [
                    'total_revenue' => (float)$stats['total_revenue'],
                    'total_orders' => (int)$stats['total_orders'],
                    'delivery_orders' => (int)$stats['delivery_orders'],
                    'walkin_orders' => (int)$stats['walkin_orders']
                ],
                'staff_breakdown' => $staff_breakdown,
                'orders' => $orders
            ]
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Database error']);
    }
} elseif ($action === 'audit_log') {
    $date = $_GET['date'] ?? date('Y-m-d');
    $search = $_GET['search'] ?? '';
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = 50;
    $offset = ($page - 1) * $limit;
    
    try {
        $whereClause = "DATE(al.Timestamp) = :date";
        $params = [':date' => $date];
        
        if ($search) {
            $whereClause .= " AND (o.OrderNumber LIKE :search OR u.FullName LIKE :search)";
            $params[':search'] = "%$search%";
        }

        // Count total
        $countSql = "SELECT COUNT(*) FROM audit_logs al 
                     LEFT JOIN users u ON al.UserID = u.UserID 
                     LEFT JOIN orders o ON al.OrderID = o.OrderID 
                     WHERE $whereClause";
        $stmt = $pdo->prepare($countSql);
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val);
        }
        $stmt->execute();
        $total = $stmt->fetchColumn();

        // Get records
        $sql = "SELECT 
                al.LogID, al.Timestamp, al.ActionType, al.PreviousStatus, al.NewStatus, al.Details,
                u.FullName as UserName, o.OrderNumber
                FROM audit_logs al 
                LEFT JOIN users u ON al.UserID = u.UserID 
                LEFT JOIN orders o ON al.OrderID = o.OrderID 
                WHERE $whereClause 
                ORDER BY al.Timestamp DESC 
                LIMIT :limit OFFSET :offset";
        $stmt = $pdo->prepare($sql);
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'status' => 'success',
            'data' => [
                'logs' => $logs,
                'pagination' => [
                    'total' => (int)$total,
                    'page' => $page,
                    'limit' => $limit,
                    'total_pages' => ceil($total / $limit)
                ]
            ]
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Database error']);
    }
} else {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
}
