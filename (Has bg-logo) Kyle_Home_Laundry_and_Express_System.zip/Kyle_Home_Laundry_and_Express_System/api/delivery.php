<?php
/**
 * Delivery API — Kyle Home Laundry and Express System
 * Handles: my_deliveries, get_delivery, mark_delivered
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/auth_middleware.php';

requireRole(ROLE_DRIVER);

$pdo = getDBConnection();

$action = $_GET['action'] ?? '';
$driverId = $_SESSION['user_id'];

try {
    if ($action === 'my_deliveries') {
        // Fetch active
        $stmt = $pdo->prepare("SELECT d.*, o.OrderNumber, c.FullName AS CustomerName 
            FROM delivery_assignments d
            JOIN orders o ON d.OrderID = o.OrderID
            JOIN customers c ON o.CustomerID = c.CustomerID
            WHERE d.DriverUserID = ? AND d.DeliveryStatus IN ('Assigned', 'Out for Delivery')
            ORDER BY d.AssignedAt DESC");
        $stmt->execute([$driverId]);
        $active = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch completed today
        $stmt = $pdo->prepare("SELECT d.*, o.OrderNumber, c.FullName AS CustomerName 
            FROM delivery_assignments d
            JOIN orders o ON d.OrderID = o.OrderID
            JOIN customers c ON o.CustomerID = c.CustomerID
            WHERE d.DriverUserID = ? AND d.DeliveryStatus = 'Delivered' AND DATE(d.DeliveredAt) = CURDATE()
            ORDER BY d.DeliveredAt DESC");
        $stmt->execute([$driverId]);
        $completed = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'active' => $active, 'completed' => $completed]);
    }
    elseif ($action === 'get_delivery') {
        $id = $_GET['id'] ?? 0;
        $stmt = $pdo->prepare("SELECT d.*, o.OrderNumber, o.Status AS OrderStatus, c.FullName AS CustomerName 
            FROM delivery_assignments d
            JOIN orders o ON d.OrderID = o.OrderID
            JOIN customers c ON o.CustomerID = c.CustomerID
            WHERE d.DeliveryID = ? AND (d.DriverUserID = ? OR d.DriverUserID IS NULL)");
        $stmt->execute([$id, $driverId]);
        $delivery = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($delivery) {
            echo json_encode(['success' => true, 'delivery' => $delivery]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Delivery not found or unauthorized']);
        }
    }
    elseif ($action === 'accept_delivery' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = $_POST['id'] ?? 0;
        
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("SELECT d.*, o.Status AS OrderStatus FROM delivery_assignments d
            JOIN orders o ON d.OrderID = o.OrderID
            WHERE d.DeliveryID = ? AND d.DriverUserID IS NULL FOR UPDATE");
        $stmt->execute([$id]);
        $delivery = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$delivery) {
            throw new Exception("Delivery not found or already assigned.");
        }
        
        // Update delivery_assignment
        $stmt = $pdo->prepare("UPDATE delivery_assignments SET DriverUserID = ?, DeliveryStatus = 'Out for Delivery', AssignedAt = NOW() WHERE DeliveryID = ?");
        $stmt->execute([$driverId, $id]);
        
        // Update order
        $orderId = $delivery['OrderID'];
        $prevStatus = $delivery['OrderStatus'];
        $newStatus = STATUS_OUT_FOR_DELIVERY;
        $stmt = $pdo->prepare("UPDATE orders SET Status = ?, LastUpdatedByUserID = ?, LastUpdatedAt = NOW() WHERE OrderID = ?");
        $stmt->execute([$newStatus, $driverId, $orderId]);
        
        writeAuditLog($pdo, $driverId, $orderId, 'Driver Accepted Delivery', $prevStatus, $newStatus, "Driver accepted and is out for delivery.");
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Delivery accepted successfully.']);
    }
    elseif ($action === 'mark_delivered' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = $_POST['id'] ?? 0;
        
        $pdo->beginTransaction();
        
        // Verify ownership and status
        $stmt = $pdo->prepare("SELECT d.*, o.Status AS OrderStatus FROM delivery_assignments d
            JOIN orders o ON d.OrderID = o.OrderID
            WHERE d.DeliveryID = ? AND d.DriverUserID = ? FOR UPDATE");
        $stmt->execute([$id, $driverId]);
        $delivery = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$delivery) {
            throw new Exception("Delivery not found or unauthorized.");
        }
        if ($delivery['DeliveryStatus'] === 'Delivered') {
            throw new Exception("Already delivered.");
        }
        
        // Update delivery_assignment
        $stmt = $pdo->prepare("UPDATE delivery_assignments SET DeliveryStatus = 'Delivered', DeliveredAt = NOW() WHERE DeliveryID = ?");
        $stmt->execute([$id]);
        
        // Update order
        $orderId = $delivery['OrderID'];
        $prevStatus = $delivery['OrderStatus'];
        $newStatus = STATUS_DELIVERED;
        $stmt = $pdo->prepare("UPDATE orders SET Status = ?, CompletedAt = NOW(), LastUpdatedByUserID = ?, LastUpdatedAt = NOW() WHERE OrderID = ?");
        $stmt->execute([$newStatus, $driverId, $orderId]);
        
        // Audit log
        writeAuditLog($pdo, $driverId, $orderId, 'Delivery Completed', $prevStatus, $newStatus, "Driver marked order as delivered.");
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Delivery marked as completed successfully.']);
    }
    else {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
