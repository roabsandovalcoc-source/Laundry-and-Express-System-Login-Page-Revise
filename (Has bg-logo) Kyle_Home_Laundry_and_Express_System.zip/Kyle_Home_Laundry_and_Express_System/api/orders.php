<?php
/**
 * Orders API — Kyle Home Laundry and Express System
 * Handles: create, pickup, assign_driver, get_drivers
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/auth_middleware.php';

$pdo = getDBConnection();
$action = $_GET['action'] ?? '';
$userId = $_SESSION['user_id'] ?? null;

if (!$userId) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

try {
    switch ($action) {
        case 'create':
            requireRole(ROLE_FRONT_DESK);
            $data = json_decode(file_get_contents('php://input'), true);
            
            $pdo->beginTransaction();

            // 1. Check or create customer
            $stmt = $pdo->prepare("SELECT CustomerID FROM customers WHERE FullName = :name AND ContactNumber = :contact LIMIT 1");
            $stmt->execute(['name' => $data['customerName'], 'contact' => $data['contactNumber']]);
            $customer = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($customer) {
                $customerId = $customer['CustomerID'];
            } else {
                $stmt = $pdo->prepare("INSERT INTO customers (FullName, ContactNumber) VALUES (:name, :contact)");
                $stmt->execute(['name' => $data['customerName'], 'contact' => $data['contactNumber']]);
                $customerId = $pdo->lastInsertId();
            }

            // 2. Create Order
            $orderNumber = generateOrderNumber($pdo);
            $stmt = $pdo->prepare("INSERT INTO orders (OrderNumber, CustomerID, WeightKg, TotalAmount, Status, IsDelivery, CreatedByUserID) 
                                   VALUES (:orderNum, :custId, :weight, :total, :status, :isDeliv, :createdBy)");
            $stmt->execute([
                'orderNum' => $orderNumber,
                'custId' => $customerId,
                'weight' => $data['weightKg'],
                'total' => $data['totalAmount'],
                'status' => STATUS_PENDING,
                'isDeliv' => $data['isDelivery'] ? 1 : 0,
                'createdBy' => $userId
            ]);
            $orderId = $pdo->lastInsertId();

            // 3. Create Service Lines
            $stmtLine = $pdo->prepare("INSERT INTO order_service_lines (OrderID, ServiceTypeID, Quantity, LineSubtotal) VALUES (:oid, :sid, :qty, :subtotal)");
            foreach ($data['services'] as $service) {
                $stmtLine->execute([
                    'oid' => $orderId,
                    'sid' => $service['serviceTypeId'],
                    'qty' => $service['quantity'],
                    'subtotal' => $service['subtotal']
                ]);
            }

            // 4. Create Delivery Assignment if needed
            if ($data['isDelivery']) {
                $stmtDeliv = $pdo->prepare("INSERT INTO delivery_assignments (OrderID, DeliveryAddress, ContactNumber, DeliveryStatus) VALUES (:oid, :addr, :contact, 'Unassigned')");
                $stmtDeliv->execute([
                    'oid' => $orderId,
                    'addr' => $data['deliveryAddress'],
                    'contact' => $data['deliveryContact']
                ]);
            }

            // 5. Audit Log
            writeAuditLog($pdo, $userId, $orderId, 'Order Created', null, STATUS_PENDING, 'New order received');

            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Order created successfully', 'orderId' => $orderId]);
            break;

        case 'pickup':
            requireRole(ROLE_FRONT_DESK);
            $data = json_decode(file_get_contents('php://input'), true);
            $orderId = $data['orderId'];

            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("SELECT Status FROM orders WHERE OrderID = :id");
            $stmt->execute(['id' => $orderId]);
            $order = $stmt->fetch();
            $prevStatus = $order['Status'];

            $stmt = $pdo->prepare("UPDATE orders SET Status = :status, CompletedAt = CURRENT_TIMESTAMP, LastUpdatedByUserID = :userId, LastUpdatedAt = CURRENT_TIMESTAMP WHERE OrderID = :id");
            $stmt->execute(['status' => STATUS_PICKED_UP, 'userId' => $userId, 'id' => $orderId]);

            writeAuditLog($pdo, $userId, $orderId, 'Status Update', $prevStatus, STATUS_PICKED_UP, 'Customer picked up the order');
            
            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Order marked as picked up']);
            break;

        case 'assign_driver':
            requireRole(ROLE_FRONT_DESK);
            $data = json_decode(file_get_contents('php://input'), true);
            $orderId = $data['orderId'];
            $driverId = $data['driverId'];

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("UPDATE delivery_assignments SET DriverUserID = :driverId, AssignedAt = CURRENT_TIMESTAMP, DeliveryStatus = 'Out for Delivery' WHERE OrderID = :id");
            $stmt->execute(['driverId' => $driverId, 'id' => $orderId]);

            // Update order status if it was Ready
            $stmt = $pdo->prepare("SELECT Status FROM orders WHERE OrderID = :id");
            $stmt->execute(['id' => $orderId]);
            $order = $stmt->fetch();
            
            $stmt = $pdo->prepare("UPDATE orders SET Status = :status, LastUpdatedByUserID = :userId, LastUpdatedAt = CURRENT_TIMESTAMP WHERE OrderID = :id");
            $stmt->execute(['status' => STATUS_OUT_FOR_DELIVERY, 'userId' => $userId, 'id' => $orderId]);

            writeAuditLog($pdo, $userId, $orderId, 'Driver Assigned & Out for Delivery', $order['Status'], STATUS_OUT_FOR_DELIVERY, "Driver ID $driverId assigned and order is Out for Delivery");

            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Driver assigned successfully']);
            break;

        case 'get_drivers':
            requireRole(ROLE_FRONT_DESK);
            $stmt = $pdo->prepare("SELECT UserID, FullName FROM users WHERE Role = :role AND IsActive = 1");
            $stmt->execute(['role' => ROLE_DRIVER]);
            $drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'drivers' => $drivers]);
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => 'Server Error: ' . $e->getMessage()]);
}
