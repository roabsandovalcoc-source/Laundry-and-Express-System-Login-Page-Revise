<?php
/**
 * Auth API — Kyle Home Laundry and Express System
 * Handles: login, logout
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth_middleware.php';

$pdo = getDBConnection();
$action = $_GET['action'] ?? '';

if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Username and password are required.']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT UserID, FullName, Username, PasswordHash, Role, IsActive FROM users WHERE Username = :username LIMIT 1");
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch();

    if ($user) {
        if ((int)$user['IsActive'] === 0) {
            echo json_encode(['success' => false, 'message' => 'Your account is disabled.']);
            exit;
        }

        // NOTE: The seed data might have plain text or different hashes. 
        // This validates against proper bcrypt hashes generated via password_hash().
        if (password_verify($password, $user['PasswordHash'])) {
            // Success
            $_SESSION['user_id'] = (int)$user['UserID'];
            $_SESSION['username'] = $user['Username'];
            $_SESSION['full_name'] = $user['FullName'];
            $_SESSION['role'] = $user['Role'];

            writeAuditLog($pdo, $user['UserID'], null, 'User Logged In', null, null, 'Login successful');

            $role = $user['Role'];
            $landing = ROLE_LANDING[$role] ?? 'index.php';

            echo json_encode([
                'success' => true,
                'redirect' => BASE_URL . $landing
            ]);
            exit;
        } else {
            // We can add a fallback check for plain text password to help the seed data work easily without hashing, but strictly speaking we should only use password_verify.
            // I'll add a developer fallback for testing purposes only as described in instructions (since it says "seed might not match... should use password_verify()").
            // Actually, if the instruction says "should use password_verify() which will work with any properly hashed password. Include a note that the actual hash needs to be generated", I will just use password_verify.
            echo json_encode(['success' => false, 'message' => 'Invalid username or password.']);
            exit;
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid username or password.']);
        exit;
    }
} elseif ($action === 'logout') {
    if (isLoggedIn()) {
        $userId = $_SESSION['user_id'];
        writeAuditLog($pdo, $userId, null, 'User Logged Out', null, null, 'Logout successful');
    }
    
    // Destroy session
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
    
    // If it's an AJAX request, return JSON. Otherwise redirect.
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode(['success' => true, 'redirect' => BASE_URL . 'pages/login.php']);
    } else {
        header('Location: ' . BASE_URL . 'pages/login.php');
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action.']);
exit;
