<?php
$pageTitle = 'Audit Trail';
$extraJS = ['financials.js'];
require_once __DIR__ . '/../../includes/auth_middleware.php';
requireRole(ROLE_MANAGER);
require_once __DIR__ . '/../../config/database.php';

$pdo = getDBConnection();
$selectedDate = $_GET['date'] ?? date('Y-m-d');
$search = $_GET['search'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 50;
$offset = ($page - 1) * $limit;

$whereClause = "DATE(al.Timestamp) = :date";
$params = [':date' => $selectedDate];

if ($search) {
    $whereClause .= " AND (o.OrderNumber LIKE :search OR u.FullName LIKE :search)";
    $params[':search'] = "%$search%";
}

// Count total
$countSql = "SELECT COUNT(*) FROM audit_logs al 
             LEFT JOIN users u ON al.UserID = u.UserID 
             LEFT JOIN orders o ON al.OrderID = o.OrderID 
             WHERE $whereClause";
$stmt = $pdo->prepare($countSql);
foreach ($params as $key => $val) {
    $stmt->bindValue($key, $val);
}
$stmt->execute();
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $limit);

// Get records
$sql = "SELECT 
        al.LogID, al.Timestamp, al.ActionType, al.PreviousStatus, al.NewStatus, al.Details,
        u.FullName as UserName, o.OrderNumber
        FROM audit_logs al 
        LEFT JOIN users u ON al.UserID = u.UserID 
        LEFT JOIN orders o ON al.OrderID = o.OrderID 
        WHERE $whereClause 
        ORDER BY al.Timestamp DESC 
        LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($sql);
foreach ($params as $key => $val) {
    $stmt->bindValue($key, $val);
}
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="manager-audit">
    <h2>Audit Trail</h2>
    <div class="filter-section card" style="margin-bottom: 20px;">
        <form method="GET" action="audit_trail.php" style="display:flex; gap:15px; align-items:center;">
            <div>
                <label for="dateFilter">Date:</label>
                <input type="date" id="dateFilter" name="date" value="<?= htmlspecialchars($selectedDate) ?>">
            </div>
            <div>
                <label for="searchFilter">Search (Order # or Staff):</label>
                <input type="text" id="searchFilter" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search...">
            </div>
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="audit_trail.php" class="btn btn-secondary">Clear</a>
        </form>
    </div>

    <div class="audit-list card">
        <table class="table">
            <thead>
                <tr>
                    <th>Timestamp</th>
                    <th>User</th>
                    <th>Action</th>
                    <th>Order Number</th>
                    <th>Previous Status</th>
                    <th>New Status</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                <tr><td colspan="7">No audit logs found for the selected criteria.</td></tr>
                <?php else: ?>
                    <?php foreach ($logs as $log): 
                        $actionColor = 'gray';
                        if (strpos($log['ActionType'], 'create') !== false) $actionColor = 'green';
                        elseif (strpos($log['ActionType'], 'change') !== false || strpos($log['ActionType'], 'update') !== false) $actionColor = 'blue';
                        elseif (strpos($log['ActionType'], 'assign') !== false) $actionColor = 'purple';
                    ?>
                    <tr>
                        <td><?= date('Y-m-d h:i A', strtotime($log['Timestamp'])) ?></td>
                        <td><?= htmlspecialchars($log['UserName'] ?? 'System') ?></td>
                        <td><span style="color: <?= $actionColor ?>; font-weight: bold;"><?= htmlspecialchars($log['ActionType']) ?></span></td>
                        <td><?= htmlspecialchars($log['OrderNumber'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($log['PreviousStatus'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($log['NewStatus'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($log['Details']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php if ($totalPages > 1): ?>
        <div class="pagination" style="margin-top: 20px; display:flex; gap: 10px;">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?date=<?= urlencode($selectedDate) ?>&search=<?= urlencode($search) ?>&page=<?= $i ?>" class="btn <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
