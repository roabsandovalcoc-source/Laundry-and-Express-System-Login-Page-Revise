<?php
$pageTitle = 'Financial Summary';
$extraJS = ['financials.js'];
require_once __DIR__ . '/../../includes/auth_middleware.php';
requireRole(ROLE_MANAGER);
require_once __DIR__ . '/../../config/database.php';

$pdo = getDBConnection();
$selectedDate = $_GET['date'] ?? date('Y-m-d');

// Load Data Server-Side for Initial Load
$stmt = $pdo->prepare("SELECT 
    COALESCE(SUM(TotalAmount), 0) as total_revenue,
    COUNT(*) as total_orders,
    SUM(CASE WHEN IsDelivery = 1 THEN 1 ELSE 0 END) as delivery_orders,
    SUM(CASE WHEN IsDelivery = 0 THEN 1 ELSE 0 END) as walkin_orders
    FROM orders 
    WHERE Status IN (?, ?) AND DATE(CompletedAt) = ?");
$stmt->execute([STATUS_DELIVERED, STATUS_PICKED_UP, $selectedDate]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Staff breakdown
$stmt = $pdo->prepare("SELECT 
    u.FullName,
    COUNT(o.OrderID) as orders_completed,
    COALESCE(SUM(o.TotalAmount), 0) as revenue
    FROM orders o
    JOIN users u ON o.LastUpdatedByUserID = u.UserID
    WHERE o.Status IN (?, ?) AND DATE(o.CompletedAt) = ?
    GROUP BY u.UserID, u.FullName
    ORDER BY revenue DESC");
$stmt->execute([STATUS_DELIVERED, STATUS_PICKED_UP, $selectedDate]);
$staff_breakdown = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Orders list
$stmt = $pdo->prepare("SELECT 
    o.OrderNumber,
    c.FullName as CustomerName,
    o.TotalAmount,
    o.Status,
    o.CompletedAt,
    u.FullName as StaffName,
    o.IsDelivery,
    (SELECT GROUP_CONCAT(st.ServiceName SEPARATOR ', ') 
     FROM order_service_lines osl 
     JOIN service_types st ON osl.ServiceTypeID = st.ServiceTypeID 
     WHERE osl.OrderID = o.OrderID) as Services
    FROM orders o
    JOIN customers c ON o.CustomerID = c.CustomerID
    LEFT JOIN users u ON o.LastUpdatedByUserID = u.UserID
    WHERE o.Status IN (?, ?) AND DATE(o.CompletedAt) = ?
    ORDER BY o.CompletedAt DESC");
$stmt->execute([STATUS_DELIVERED, STATUS_PICKED_UP, $selectedDate]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="manager-dashboard">
    <h2>Financial Summary</h2>

    <div class="filter-section card" style="margin-bottom: 20px;">
        <form method="GET" action="financial_summary.php" style="display: flex; gap: 15px; align-items: center;">
            <div>
                <label for="dateFilter">Select Date:</label>
                <input type="date" id="dateFilter" name="date" value="<?= htmlspecialchars($selectedDate) ?>">
            </div>
            <button type="submit" class="btn btn-primary">Filter</button>
        </form>
    </div>

    <div class="dashboard-stats" style="display:flex; gap: 20px; margin-bottom: 20px;">
        <div class="stat-card card" style="flex: 1;">
            <h3>Total Revenue</h3>
            <p class="stat-value" style="font-size: 24px; font-weight: bold; color: var(--primary-color);">₱<?= number_format($stats['total_revenue'] ?? 0, 2) ?></p>
        </div>
        <div class="stat-card card" style="flex: 1;">
            <h3>Orders Completed</h3>
            <p class="stat-value" style="font-size: 24px; font-weight: bold;"><?= (int)$stats['total_orders'] ?></p>
        </div>
        <div class="stat-card card" style="flex: 1;">
            <h3>Delivery Orders</h3>
            <p class="stat-value" style="font-size: 24px; font-weight: bold;"><?= (int)$stats['delivery_orders'] ?></p>
        </div>
        <div class="stat-card card" style="flex: 1;">
            <h3>Walk-in Orders</h3>
            <p class="stat-value" style="font-size: 24px; font-weight: bold;"><?= (int)$stats['walkin_orders'] ?></p>
        </div>
    </div>

    <div class="dashboard-tables" style="display:flex; gap:20px;">
        <div class="staff-breakdown card" style="flex:1;">
            <h3>Staff Revenue Breakdown</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Staff Name</th>
                        <th>Orders Completed</th>
                        <th>Revenue Contribution</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($staff_breakdown)): ?>
                    <tr><td colspan="3">No staff activity for this date.</td></tr>
                    <?php else: ?>
                        <?php foreach ($staff_breakdown as $staff): ?>
                        <tr>
                            <td><?= htmlspecialchars($staff['FullName']) ?></td>
                            <td><?= $staff['orders_completed'] ?></td>
                            <td>₱<?= number_format($staff['revenue'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="orders-list card" style="margin-top:20px;">
        <h3>Completed Orders</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Order Number</th>
                    <th>Customer</th>
                    <th>Services</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Completed At</th>
                    <th>Completed By</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                <tr><td colspan="7">No completed orders for this date.</td></tr>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= htmlspecialchars($order['OrderNumber']) ?></td>
                        <td><?= htmlspecialchars($order['CustomerName']) ?></td>
                        <td><?= htmlspecialchars($order['Services'] ?? 'N/A') ?></td>
                        <td>₱<?= number_format($order['TotalAmount'], 2) ?></td>
                        <td><span class="badge <?= statusClass($order['Status']) ?>"><?= htmlspecialchars($order['Status']) ?></span></td>
                        <td><?= date('h:i A', strtotime($order['CompletedAt'])) ?></td>
                        <td><?= htmlspecialchars($order['StaffName'] ?? 'Unknown') ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<?php
/**
 * Map order status to CSS badge class.
 */
function statusClass(string $status): string {
    return match($status) {
        'Pending'              => 'status-pending',
        'Washing'              => 'status-washing',
        'Drying'               => 'status-drying',
        'Folding and Packing'  => 'status-folding',
        'Ready'                => 'status-ready',
        'Out for Delivery'     => 'status-out-for-delivery',
        'Picked Up'            => 'status-picked-up',
        'Delivered'            => 'status-delivered',
        default                => 'status-pending',
    };
}
?>
