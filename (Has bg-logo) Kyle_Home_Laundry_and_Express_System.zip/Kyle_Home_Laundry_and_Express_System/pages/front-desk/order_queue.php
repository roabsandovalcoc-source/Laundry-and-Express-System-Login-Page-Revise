<?php
$pageTitle = 'Order Queue';
$extraJS = ['orders.js'];
require_once __DIR__ . '/../../includes/auth_middleware.php';
requireRole(ROLE_FRONT_DESK);
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/constants.php';

$pdo = getDBConnection();

$today = date('Y-m-d');
$statsQuery = "SELECT 
    COUNT(CASE WHEN DATE(ReceivedAt) = :today THEN 1 END) as TotalToday,
    COUNT(CASE WHEN Status = :pending THEN 1 END) as Pending,
    COUNT(CASE WHEN Status = :ready THEN 1 END) as Ready,
    COUNT(CASE WHEN Status = :outDelivery THEN 1 END) as OutDelivery
    FROM orders";
$stmt = $pdo->prepare($statsQuery);
$stmt->execute([
    'today' => $today,
    'pending' => STATUS_PENDING,
    'ready' => STATUS_READY,
    'outDelivery' => STATUS_OUT_FOR_DELIVERY
]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

$ordersQuery = "
    SELECT o.*, c.FullName as CustomerName, c.ContactNumber,
    (SELECT GROUP_CONCAT(st.ServiceName SEPARATOR ', ') 
     FROM order_service_lines osl 
     JOIN service_types st ON osl.ServiceTypeID = st.ServiceTypeID 
     WHERE osl.OrderID = o.OrderID) as Services
    FROM orders o 
    JOIN customers c ON o.CustomerID = c.CustomerID 
    ORDER BY o.ReceivedAt DESC";
$ordersStmt = $pdo->query($ordersQuery);
$orders = $ordersStmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <h1>Order Queue</h1>
    <p>Manage and track all laundry orders</p>
</div>

<!-- Stat Cards -->
<div class="stats-grid">
    <div class="stat-card stat-primary">
        <span class="stat-icon">📋</span>
        <span class="stat-label">Total Orders Today</span>
        <span class="stat-value"><?= htmlspecialchars($stats['TotalToday']) ?></span>
    </div>
    <div class="stat-card stat-warning">
        <span class="stat-icon">⏳</span>
        <span class="stat-label">Pending</span>
        <span class="stat-value"><?= htmlspecialchars($stats['Pending']) ?></span>
    </div>
    <div class="stat-card stat-success">
        <span class="stat-icon">✅</span>
        <span class="stat-label">Ready for Pickup</span>
        <span class="stat-value"><?= htmlspecialchars($stats['Ready']) ?></span>
    </div>
    <div class="stat-card stat-info">
        <span class="stat-icon">🚚</span>
        <span class="stat-label">Out for Delivery</span>
        <span class="stat-value"><?= htmlspecialchars($stats['OutDelivery']) ?></span>
    </div>
</div>

<!-- Toolbar -->
<div class="toolbar">
    <div class="search-box">
        <input type="text" id="orderSearch" class="form-control" placeholder="Search by Order Number or Customer Name">
    </div>
    <div class="d-flex gap-2 align-center">
        <select id="statusFilter" class="form-control" style="width: auto;">
            <option value="">All Statuses</option>
            <option value="<?= STATUS_PENDING ?>">Pending</option>
            <option value="<?= STATUS_WASHING ?>">Washing</option>
            <option value="<?= STATUS_DRYING ?>">Drying</option>
            <option value="<?= STATUS_FOLDING_AND_PACKING ?>">Folding and Packing</option>
            <option value="<?= STATUS_READY ?>">Ready</option>
            <option value="<?= STATUS_OUT_FOR_DELIVERY ?>">Out for Delivery</option>
            <option value="<?= STATUS_PICKED_UP ?>">Picked Up</option>
            <option value="<?= STATUS_DELIVERED ?>">Delivered</option>
        </select>
        <a href="<?= BASE_URL ?>pages/front-desk/new_order.php" class="btn btn-primary">+ New Order</a>
    </div>
</div>

<!-- Orders Table -->
<?php if (empty($orders)): ?>
    <div class="empty-state">
        <div class="empty-icon">📭</div>
        <h3>No Orders Yet</h3>
        <p>Create your first order to get started.</p>
        <a href="<?= BASE_URL ?>pages/front-desk/new_order.php" class="btn btn-primary mt-4">Create New Order</a>
    </div>
<?php else: ?>
    <div class="table-wrapper">
        <table class="data-table" id="ordersTable">
            <thead>
                <tr>
                    <th>Order Number</th>
                    <th>Customer Name</th>
                    <th>Services</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr data-status="<?= htmlspecialchars($order['Status']) ?>">
                        <td class="order-number"><?= htmlspecialchars($order['OrderNumber']) ?></td>
                        <td class="customer-name"><?= htmlspecialchars($order['CustomerName']) ?></td>
                        <td><?= htmlspecialchars($order['Services'] ?? '') ?></td>
                        <td>₱<?= number_format($order['TotalAmount'], 2) ?></td>
                        <td>
                            <span class="status-badge <?= statusBadgeClass($order['Status']) ?>">
                                <?= htmlspecialchars($order['Status']) ?>
                            </span>
                        </td>
                        <td><?= date('M d, Y h:i A', strtotime($order['ReceivedAt'])) ?></td>
                        <td>
                            <a href="<?= BASE_URL ?>pages/front-desk/order_details.php?id=<?= $order['OrderID'] ?>" class="btn btn-sm btn-primary">View</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<?php
/**
 * Map order status to CSS badge class.
 */
function statusBadgeClass(string $status): string {
    return match($status) {
        'Pending'              => 'status-pending',
        'Washing'              => 'status-washing',
        'Drying'               => 'status-drying',
        'Folding and Packing'  => 'status-folding',
        'Ready'                => 'status-ready',
        'Out for Delivery'     => 'status-out-for-delivery',
        'Picked Up'            => 'status-picked-up',
        'Delivered'            => 'status-delivered',
        default                => 'status-pending',
    };
}
?>
