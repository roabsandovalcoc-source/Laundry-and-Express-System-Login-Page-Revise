<?php
$pageTitle = 'New Order';
$extraJS = ['orders.js'];
require_once __DIR__ . '/../../includes/auth_middleware.php';
requireRole(ROLE_FRONT_DESK);
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/constants.php';

$pdo = getDBConnection();
// Fetch service types to build the form
$stmt = $pdo->query("SELECT * FROM service_types ORDER BY ServiceName");
$serviceTypes = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container mt-4">
    <h2>Create New Order</h2>
    
    <form id="newOrderForm" class="mt-4">
        <div class="card mb-4">
            <div class="card-header">Customer Information</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="customerName" class="form-label">Full Name *</label>
                        <input type="text" class="form-control" id="customerName" name="customerName" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="contactNumber" class="form-label">Contact Number</label>
                        <input type="text" class="form-control" id="contactNumber" name="contactNumber">
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header">Laundry Details</div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="weightKg" class="form-label">Weight (kg) *</label>
                        <input type="number" step="0.1" min="0.1" class="form-control" id="weightKg" name="weightKg" required>
                    </div>
                </div>
                <h5>Services</h5>
                <div id="servicesContainer">
                    <?php foreach ($serviceTypes as $service): ?>
                        <div class="row align-items-center mb-2 service-row">
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input class="form-check-input service-checkbox" type="checkbox" 
                                        name="services[<?= $service['ServiceTypeID'] ?>][selected]" 
                                        value="1" 
                                        id="service_<?= $service['ServiceTypeID'] ?>" 
                                        data-rate="<?= $service['Rate'] ?>"
                                        data-name="<?= htmlspecialchars($service['ServiceName']) ?>">
                                    <label class="form-check-label" for="service_<?= $service['ServiceTypeID'] ?>">
                                        <?= htmlspecialchars($service['ServiceName']) ?> (₱<?= number_format($service['Rate'], 2) ?>/unit)
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <input type="number" min="1" class="form-control service-qty" 
                                    name="services[<?= $service['ServiceTypeID'] ?>][quantity]" 
                                    placeholder="Quantity" disabled>
                            </div>
                            <div class="col-md-4 text-end">
                                <span class="service-subtotal">₱0.00</span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header">Delivery Option</div>
            <div class="card-body">
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" id="isDelivery" name="isDelivery" value="1">
                    <label class="form-check-label" for="isDelivery">
                        Request Delivery
                    </label>
                </div>
                <div id="deliveryFields" style="display: none;">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="deliveryAddress" class="form-label">Delivery Address *</label>
                            <textarea class="form-control" id="deliveryAddress" name="deliveryAddress" rows="2"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="deliveryContact" class="form-label">Delivery Contact Number *</label>
                            <input type="text" class="form-control" id="deliveryContact" name="deliveryContact">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4 bg-light">
            <div class="card-body d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Total Amount:</h4>
                <h3 class="mb-0 text-primary" id="totalAmountDisplay">₱0.00</h3>
            </div>
        </div>

        <div class="text-end mb-5">
            <a href="<?= BASE_URL ?>pages/front-desk/order_queue.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary btn-lg" id="submitOrderBtn">Create Order</button>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
