<?php
$pageTitle = 'Order Details';
$extraJS = ['orders.js'];
require_once __DIR__ . '/../../includes/auth_middleware.php';
requireRole([ROLE_FRONT_DESK, ROLE_WASHER_FOLDER]);
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/constants.php';

$pdo = getDBConnection();
$backUrl = BASE_URL . (ROLE_LANDING[$_SESSION['role']] ?? 'pages/login.php');
$orderId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$orderId) {
    header("Location: " . $backUrl);
    exit;
}

// Fetch order details
$stmt = $pdo->prepare("SELECT o.*, c.FullName as CustomerName, c.ContactNumber 
    FROM orders o JOIN customers c ON o.CustomerID = c.CustomerID 
    WHERE o.OrderID = :id");
$stmt->execute(['id' => $orderId]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    require_once __DIR__ . '/../../includes/header.php';
    echo "<div class='page-header'><h1>Order Not Found</h1></div>";
    echo "<div class='alert alert-danger'>The requested order could not be found.</div>";
    echo "<a href='" . htmlspecialchars($backUrl, ENT_QUOTES) . "' class='btn btn-primary'>Back to Queue</a>";
    require_once __DIR__ . '/../../includes/footer.php';
    exit;
}

// Fetch service lines
$stmt = $pdo->prepare("SELECT osl.*, st.ServiceName, st.Rate 
    FROM order_service_lines osl 
    JOIN service_types st ON osl.ServiceTypeID = st.ServiceTypeID 
    WHERE osl.OrderID = :id");
$stmt->execute(['id' => $orderId]);
$serviceLines = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch delivery assignment if any
$delivery = null;
if ($order['IsDelivery']) {
    $stmt = $pdo->prepare("SELECT da.*, u.FullName as DriverName 
        FROM delivery_assignments da 
        LEFT JOIN users u ON da.DriverUserID = u.UserID 
        WHERE da.OrderID = :id");
    $stmt->execute(['id' => $orderId]);
    $delivery = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Fetch audit logs
$stmt = $pdo->prepare("SELECT a.*, u.FullName as UserName 
    FROM audit_logs a 
    LEFT JOIN users u ON a.UserID = u.UserID 
    WHERE a.OrderID = :id ORDER BY a.Timestamp DESC");
$stmt->execute(['id' => $orderId]);
$auditLogs = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Order Details: <?= htmlspecialchars($order['OrderNumber']) ?></h2>
        <a href="<?= htmlspecialchars($backUrl, ENT_QUOTES) ?>" class="btn btn-secondary">Back to Queue</a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Order Information</h5>
                    <span class="badge status-badge fs-6" data-status="<?= htmlspecialchars($order['Status']) ?>">
                        <?= htmlspecialchars($order['Status']) ?>
                    </span>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Customer:</strong> <?= htmlspecialchars($order['CustomerName']) ?><br>
                            <strong>Contact:</strong> <?= htmlspecialchars($order['ContactNumber']) ?>
                        </div>
                        <div class="col-md-6">
                            <strong>Received At:</strong> <?= date('M d, Y h:i A', strtotime($order['ReceivedAt'])) ?><br>
                            <strong>Weight:</strong> <?= htmlspecialchars($order['WeightKg']) ?> kg<br>
                            <?php if ($order['MachineNumber']): ?>
                                <strong>Machine Number:</strong> <?= htmlspecialchars($order['MachineNumber']) ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Service</th>
                                <th>Rate</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($serviceLines as $line): ?>
                                <tr>
                                    <td><?= htmlspecialchars($line['ServiceName']) ?></td>
                                    <td>₱<?= number_format($line['Rate'], 2) ?></td>
                                    <td><?= htmlspecialchars($line['Quantity']) ?></td>
                                    <td>₱<?= number_format($line['LineSubtotal'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3" class="text-end">Total Amount:</th>
                                <th>₱<?= number_format($order['TotalAmount'], 2) ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <?php if ($order['IsDelivery'] && $delivery): ?>
                <div class="card mb-4">
                    <div class="card-header">Delivery Information</div>
                    <div class="card-body">
                        <p><strong>Address:</strong> <?= htmlspecialchars($delivery['DeliveryAddress']) ?></p>
                        <p><strong>Contact:</strong> <?= htmlspecialchars($delivery['ContactNumber']) ?></p>
                        <p><strong>Status:</strong> <?= htmlspecialchars($delivery['DeliveryStatus']) ?></p>
                        <p><strong>Assigned Driver:</strong> <?= $delivery['DriverName'] ? htmlspecialchars($delivery['DriverName']) : 'Unassigned' ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-header">Status History</div>
                <ul class="list-group list-group-flush">
                    <?php foreach ($auditLogs as $log): ?>
                        <li class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1"><?= htmlspecialchars($log['ActionType']) ?></h6>
                                <small><?= date('M d, Y h:i A', strtotime($log['Timestamp'])) ?></small>
                            </div>
                            <p class="mb-1">
                                <?php if ($log['PreviousStatus'] && $log['NewStatus']): ?>
                                    Status changed from <em><?= htmlspecialchars($log['PreviousStatus']) ?></em> to <em><?= htmlspecialchars($log['NewStatus']) ?></em>
                                <?php endif; ?>
                            </p>
                            <?php if ($log['Details']): ?>
                                <small class="text-muted"><?= htmlspecialchars($log['Details']) ?></small>
                            <?php endif; ?>
                            <small class="d-block">By: <?= htmlspecialchars($log['UserName'] ?? 'System') ?></small>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">Actions</div>
                <div class="card-body">
                    <?php if ($_SESSION['role'] === ROLE_FRONT_DESK): ?>
                        <?php if ($order['Status'] === STATUS_READY && !$order['IsDelivery']): ?>
                            <button class="btn btn-success w-100 mb-2" id="btnMarkPickedUp" data-id="<?= $order['OrderID'] ?>">
                                Mark as Picked Up
                            </button>
                        <?php endif; ?>

                        <?php if ($order['Status'] === STATUS_READY && $order['IsDelivery']): ?>
                            <button class="btn btn-primary w-100 mb-2" id="btnAssignDriver">
                                Assign Driver
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <button class="btn btn-outline-secondary w-100 mt-2" onclick="window.print()">Print Receipt</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Assign Driver Modal -->
<div class="modal-overlay" id="assignDriverModal">
  <div class="modal">
    <div class="modal-header">
      <h3>Assign Driver</h3>
      <button type="button" class="modal-close" id="closeDriverModal">&times;</button>
    </div>
    <div class="modal-body">
        <div class="form-group">
            <input type="hidden" id="modalOrderId" value="<?= $order['OrderID'] ?>">
            <label for="driverSelect" class="form-label">Select Driver</label>
            <select class="form-control" id="driverSelect" required>
                <option value="">Loading drivers...</option>
            </select>
        </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-outline" id="cancelDriverModal">Cancel</button>
      <button type="button" class="btn btn-primary" id="submitDriverAssignment">Assign</button>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

