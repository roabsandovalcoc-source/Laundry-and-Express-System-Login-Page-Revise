<?php
$pageTitle = 'Kanban Board';
$extraCSS = ['kanban_v2.css'];
$extraJS  = ['kanban.js'];
require_once __DIR__ . '/../../includes/auth_middleware.php';
requireRole(ROLE_WASHER_FOLDER);
require_once __DIR__ . '/../../config/database.php';

require_once __DIR__ . '/../../includes/header.php';
?>
<div class="kanban-container">
    <div class="kanban-board" id="kanbanBoard">
        <!-- Columns will be populated by JS -->
    </div>
</div>

<!-- Machine Number Modal -->
<div id="machineModal" class="modal-overlay">
    <div class="modal">
        <div class="modal-header">
            <h3>Enter Machine Number</h3>
            <button type="button" class="modal-close" id="closeMachineModal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">Machine Number</label>
                <input type="text" id="machineNumberInput" class="form-control" placeholder="e.g. W1, D2">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline" id="cancelMachineModal">Cancel</button>
            <button id="submitMachineNumber" class="btn btn-primary">Submit</button>
        </div>
    </div>
</div>

<script>
    const KANBAN_API_URL = '<?php echo BASE_URL; ?>api/status.php';
    const ORDER_DETAILS_URL = '<?php echo BASE_URL; ?>pages/front-desk/order_details.php?id=';
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
