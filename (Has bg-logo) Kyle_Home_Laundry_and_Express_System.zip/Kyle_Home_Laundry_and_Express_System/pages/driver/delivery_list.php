<?php
$pageTitle = 'My Deliveries';
$extraCSS = ['driver_v2.css'];
$extraJS = ['driver.js'];

require_once __DIR__ . '/../../includes/auth_middleware.php';
requireRole(ROLE_DRIVER);
require_once __DIR__ . '/../../config/database.php';

$pdo = getDBConnection();
$driverId = $_SESSION['user_id'];

// Fetch Available
$stmt = $pdo->prepare("SELECT d.*, o.OrderNumber, c.FullName AS CustomerName 
    FROM delivery_assignments d
    JOIN orders o ON d.OrderID = o.OrderID
    JOIN customers c ON o.CustomerID = c.CustomerID
    WHERE d.DeliveryStatus = 'Unassigned' AND o.Status = 'Ready'
    ORDER BY o.LastUpdatedAt ASC");
$stmt->execute();
$availableDeliveries = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch Active
$stmt = $pdo->prepare("SELECT d.*, o.OrderNumber, c.FullName AS CustomerName 
    FROM delivery_assignments d
    JOIN orders o ON d.OrderID = o.OrderID
    JOIN customers c ON o.CustomerID = c.CustomerID
    WHERE d.DriverUserID = ? AND d.DeliveryStatus IN ('Assigned', 'Out for Delivery')
    ORDER BY d.AssignedAt DESC");
$stmt->execute([$driverId]);
$activeDeliveries = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch Completed Today
$stmt = $pdo->prepare("SELECT d.*, o.OrderNumber, c.FullName AS CustomerName 
    FROM delivery_assignments d
    JOIN orders o ON d.OrderID = o.OrderID
    JOIN customers c ON o.CustomerID = c.CustomerID
    WHERE d.DriverUserID = ? AND d.DeliveryStatus = 'Delivered' AND DATE(d.DeliveredAt) = CURDATE()
    ORDER BY d.DeliveredAt DESC");
$stmt->execute([$driverId]);
$completedDeliveries = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../../includes/header.php';
?>
<div class="driver-container">
    <div class="driver-stats">
        <div class="stat-card">
            <h3><?= count($availableDeliveries) ?></h3>
            <p>Available</p>
        </div>
        <div class="stat-card">
            <h3><?= count($activeDeliveries) ?></h3>
            <p>Active</p>
        </div>
        <div class="stat-card">
            <h3><?= count($completedDeliveries) ?></h3>
            <p>Completed Today</p>
        </div>
    </div>

    <div class="driver-tabs">
        <button class="tab-btn active" data-target="available-list">Available</button>
        <button class="tab-btn" data-target="active-list">Active Deliveries</button>
        <button class="tab-btn" data-target="completed-list">Completed</button>
    </div>

    <div id="available-list" class="tab-content active">
        <?php if (count($availableDeliveries) > 0): ?>
            <?php foreach ($availableDeliveries as $del): ?>
                <div class="delivery-card">
                    <div class="delivery-header">
                        <span class="order-number"><?= htmlspecialchars($del['OrderNumber']) ?></span>
                        <span class="badge status-pending">Ready</span>
                    </div>
                    <div class="delivery-body">
                        <h4><?= htmlspecialchars($del['CustomerName']) ?></h4>
                        <p class="address"><i class="icon-map-marker"></i> <?= htmlspecialchars($del['DeliveryAddress']) ?></p>
                        <p class="contact"><i class="icon-phone"></i> <?= htmlspecialchars($del['ContactNumber']) ?></p>
                    </div>
                    <div class="delivery-footer" style="margin-top: 15px;">
                        <a href="<?= BASE_URL ?>pages/driver/delivery_details.php?id=<?= $del['DeliveryID'] ?>" class="btn btn-primary btn-block">View & Accept</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <p>No available deliveries at the moment.</p>
            </div>
        <?php endif; ?>
    </div>

    <div id="active-list" class="tab-content">
        <?php if (count($activeDeliveries) > 0): ?>
            <?php foreach ($activeDeliveries as $del): ?>
                <div class="delivery-card">
                    <div class="delivery-header">
                        <span class="order-number"><?= htmlspecialchars($del['OrderNumber']) ?></span>
                        <span class="badge status-<?= strtolower(str_replace(' ', '-', $del['DeliveryStatus'])) ?>"><?= htmlspecialchars($del['DeliveryStatus']) ?></span>
                    </div>
                    <div class="delivery-body">
                        <h4><?= htmlspecialchars($del['CustomerName']) ?></h4>
                        <p class="address"><i class="icon-map-marker"></i> <?= htmlspecialchars($del['DeliveryAddress']) ?></p>
                        <p class="contact"><i class="icon-phone"></i> <?= htmlspecialchars($del['ContactNumber']) ?></p>
                        <p class="time"><small>Assigned: <?= date('M j, g:i A', strtotime($del['AssignedAt'])) ?></small></p>
                    </div>
                    <div class="delivery-footer" style="margin-top: 15px;">
                        <a href="<?= BASE_URL ?>pages/driver/delivery_details.php?id=<?= $del['DeliveryID'] ?>" class="btn btn-primary btn-block">View Details</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <p>No active deliveries assigned.</p>
            </div>
        <?php endif; ?>
    </div>

    <div id="completed-list" class="tab-content">
        <?php if (count($completedDeliveries) > 0): ?>
            <?php foreach ($completedDeliveries as $del): ?>
                <div class="delivery-card completed-card">
                    <div class="delivery-header">
                        <span class="order-number"><?= htmlspecialchars($del['OrderNumber']) ?></span>
                        <span class="badge status-delivered">Delivered</span>
                    </div>
                    <div class="delivery-body">
                        <h4><?= htmlspecialchars($del['CustomerName']) ?></h4>
                        <p class="address"><i class="icon-map-marker"></i> <?= htmlspecialchars($del['DeliveryAddress']) ?></p>
                        <p class="time"><small>Delivered: <?= date('M j, g:i A', strtotime($del['DeliveredAt'])) ?></small></p>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <p>No deliveries completed today.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
