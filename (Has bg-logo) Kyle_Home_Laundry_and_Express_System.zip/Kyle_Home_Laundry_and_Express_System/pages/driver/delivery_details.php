<?php
$pageTitle = 'Delivery Details';
$extraCSS = ['driver_v2.css'];
$extraJS = ['driver.js'];

require_once __DIR__ . '/../../includes/auth_middleware.php';
requireRole(ROLE_DRIVER);
require_once __DIR__ . '/../../config/database.php';

$pdo = getDBConnection();
$driverId = $_SESSION['user_id'];
$deliveryId = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("SELECT d.*, o.OrderNumber, o.Status AS OrderStatus, o.TotalAmount, o.IsDelivery, c.FullName AS CustomerName 
    FROM delivery_assignments d
    JOIN orders o ON d.OrderID = o.OrderID
    JOIN customers c ON o.CustomerID = c.CustomerID
    WHERE d.DeliveryID = ? AND (d.DriverUserID = ? OR d.DriverUserID IS NULL)");
$stmt->execute([$deliveryId, $driverId]);
$delivery = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$delivery) {
    die("Delivery not found or unauthorized.");
}

// Fetch order lines
$stmt = $pdo->prepare("SELECT l.*, s.ServiceName FROM order_service_lines l JOIN service_types s ON l.ServiceTypeID = s.ServiceTypeID WHERE l.OrderID = ?");
$stmt->execute([$delivery['OrderID']]);
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../../includes/header.php';
?>
<div class="driver-container detail-view">
    <a href="<?= BASE_URL ?>pages/driver/delivery_list.php" class="back-link">&larr; Back to List</a>
    
    <div class="delivery-card">
        <div class="delivery-header">
            <span class="order-number"><?= htmlspecialchars($delivery['OrderNumber']) ?></span>
            <span class="badge status-<?= strtolower(str_replace(' ', '-', $delivery['DeliveryStatus'])) ?>"><?= htmlspecialchars($delivery['DeliveryStatus']) ?></span>
        </div>
        <div class="delivery-body">
            <h3><?= htmlspecialchars($delivery['CustomerName']) ?></h3>
            
            <div class="address-box">
                <strong>Delivery Address:</strong>
                <p class="large-address"><?= htmlspecialchars($delivery['DeliveryAddress']) ?></p>
            </div>

            <div class="action-buttons">
                <a href="tel:<?= htmlspecialchars($delivery['ContactNumber']) ?>" class="btn btn-info btn-block btn-call">
                    <i class="icon-phone"></i> Call <?= htmlspecialchars($delivery['ContactNumber']) ?>
                </a>
            </div>
            
            <div class="order-contents" style="margin-top: 15px; margin-bottom: 15px;">
                <strong>Order Contents:</strong>
                <ul>
                    <?php foreach ($services as $srv): ?>
                        <li><?= htmlspecialchars($srv['ServiceName']) ?> (x<?= htmlspecialchars($srv['Quantity']) ?>)</li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        
        <?php if ($delivery['DeliveryStatus'] === 'Unassigned' && $delivery['OrderStatus'] === 'Ready'): ?>
            <div class="delivery-footer">
                <button type="button" class="btn btn-primary btn-block btn-large" id="btn-accept-delivery" data-id="<?= $delivery['DeliveryID'] ?>">
                    Accept Delivery
                </button>
            </div>
        <?php endif; ?>
        
        <?php if (in_array($delivery['DeliveryStatus'], ['Assigned', 'Out for Delivery'])): ?>
            <div class="delivery-footer">
                <button type="button" class="btn btn-success btn-block btn-large" id="btn-mark-delivered" data-id="<?= $delivery['DeliveryID'] ?>">
                    Mark as Delivered
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
