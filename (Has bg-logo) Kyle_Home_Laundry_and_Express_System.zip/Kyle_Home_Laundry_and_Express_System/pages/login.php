<?php
require_once __DIR__ . '/../includes/auth_middleware.php';

// If already logged in, redirect to respective dashboard
if (isLoggedIn()) {
    $role = $_SESSION['role'];
    $landing = ROLE_LANDING[$role] ?? 'index.php';
    redirect($landing);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo htmlspecialchars(APP_NAME); ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/main_v2.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/login_v2.css?v=<?php echo time(); ?>">
</head>
<body class="login-body dark-glass-theme">
    <div class="background-orbs">
        <div class="orb orb-1"></div>
        <div class="orb orb-2"></div>
        <div class="orb orb-3"></div>
        <div class="orb orb-4"></div>
    </div>
    
    <div class="login-container glass-card">
        <div class="login-header">
            <img src="<?php echo BASE_URL; ?>assets/images/Laundry_System_logo.jpg" alt="Logo" style="width: 140px; height: 140px; object-fit: cover; margin: 0 auto 15px; display: block; border-radius: 16px; box-shadow: 0 8px 20px rgba(0,0,0,0.4);">
            <h1><?php echo htmlspecialchars(APP_NAME); ?></h1>
            <p>Please log in to continue</p>
        </div>
            
            <div id="loginAlert" class="alert hidden"></div>

            <form id="loginForm" class="login-form">
                <div class="form-group input-with-icon">
                    <span class="input-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
                        </svg>
                    </span>
                    <input type="text" id="username" name="username" class="form-control glass-input" placeholder="Username" required autofocus>
                </div>

                <div class="form-group input-with-icon">
                    <span class="input-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
                            <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/>
                        </svg>
                    </span>
                    <input type="password" id="password" name="password" class="form-control glass-input" placeholder="Password" required>
                </div>

                <button type="submit" class="btn btn-glass btn-block" id="loginBtn">
                    <span class="btn-text">Log In</span>
                    <span class="spinner hidden" id="loginSpinner"></span>
                </button>
                

            </form>
            

    </div>
    
    <script>
        const BASE_URL = '<?php echo BASE_URL; ?>';
    </script>
    <script src="<?php echo BASE_URL; ?>assets/js/login.js"></script>
</body>
</html>
