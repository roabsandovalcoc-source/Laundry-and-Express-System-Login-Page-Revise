<?php
/**
 * Entry Point — index.php
 * Kyle Home Laundry and Express System
 *
 * Redirects to the appropriate landing page based on login state and role.
 */

session_start();
require_once __DIR__ . '/config/constants.php';

// If not logged in, redirect to login
if (!isset($_SESSION['user_id'], $_SESSION['role'])) {
    header('Location: ' . BASE_URL . 'pages/login.php');
    exit;
}

// Redirect to role-specific landing page
$role = $_SESSION['role'];
$landing = ROLE_LANDING[$role] ?? 'pages/login.php';

header('Location: ' . BASE_URL . $landing);
exit;
