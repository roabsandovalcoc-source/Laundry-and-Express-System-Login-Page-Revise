
</main><!-- /.main-content -->

<!-- ── Footer ── -->
<footer class="app-footer">
    <p>&copy; <?= date('Y') ?> <?= APP_NAME ?>. All rights reserved.</p>
</footer>

<!-- ── Global JS ── -->
<script>const BASE_URL = '<?= BASE_URL ?>';</script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<?php if (isset($extraJS) && is_array($extraJS)): ?>
    <?php foreach ($extraJS as $js): ?>
        <script src="<?= BASE_URL ?>assets/js/<?= $js ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
</body>
</html>
