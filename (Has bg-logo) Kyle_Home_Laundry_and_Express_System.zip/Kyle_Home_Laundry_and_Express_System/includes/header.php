<?php
/**
 * Shared Header Include
 * Kyle Home Laundry and Express System
 *
 * Usage: include this at the top of every page after auth_middleware.
 * Sets the $pageTitle variable before including.
 */

require_once __DIR__ . '/../config/constants.php';

$user = currentUser();
$role = $user['role'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? APP_NAME) ?> — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/main_v2.css?v=<?= time() ?>">
    <?php if (isset($extraCSS) && is_array($extraCSS)): ?>
        <?php foreach ($extraCSS as $css): ?>
            <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/<?= $css ?>?v=<?= time() ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>

<!-- ── Top Navigation Bar ── -->
<nav class="navbar">
    <div class="navbar-brand">
        <img src="<?= BASE_URL ?>assets/images/Laundry_System_logo.jpg" alt="Logo" style="height: 55px; width: auto; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.2);">
        <span class="navbar-title"><?= APP_NAME ?></span>
    </div>

    <div class="navbar-menu" id="navbarMenu">
        <?php if ($role === ROLE_FRONT_DESK): ?>
            <a href="<?= BASE_URL ?>pages/front-desk/order_queue.php" class="nav-link">Order Queue</a>
            <a href="<?= BASE_URL ?>pages/front-desk/new_order.php" class="nav-link">New Order</a>
        <?php elseif ($role === ROLE_WASHER_FOLDER): ?>
            <a href="<?= BASE_URL ?>pages/washer/kanban.php" class="nav-link">Kanban Board</a>
        <?php elseif ($role === ROLE_DRIVER): ?>
            <a href="<?= BASE_URL ?>pages/driver/delivery_list.php" class="nav-link">My Deliveries</a>
        <?php elseif ($role === ROLE_MANAGER): ?>
            <a href="<?= BASE_URL ?>pages/manager/financial_summary.php" class="nav-link">Financial Summary</a>
            <a href="<?= BASE_URL ?>pages/manager/audit_trail.php" class="nav-link">Audit Trail</a>
        <?php endif; ?>
    </div>

    <div class="navbar-user">
        <span class="user-badge"><?= htmlspecialchars($user['full_name']) ?></span>
        <span class="role-badge"><?= htmlspecialchars(ucwords(str_replace('_', ' ', $role))) ?></span>
        <a href="<?= BASE_URL ?>api/auth.php?action=logout" class="btn btn-sm btn-outline">Logout</a>
    </div>

    <button class="navbar-toggle" id="navbarToggle" aria-label="Toggle navigation">☰</button>
</nav>

<!-- ── Page Content Wrapper ── -->
<main class="main-content">
