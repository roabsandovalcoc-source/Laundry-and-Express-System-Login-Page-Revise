<?php
/**
 * Authentication Middleware
 * Kyle Home Laundry and Express System
 *
 * Include this file at the top of every protected page.
 * It starts the session, checks login status, and optionally
 * enforces role-based access.
 */

session_start();

require_once __DIR__ . '/../config/constants.php';

/**
 * Redirect helper.
 */
function redirect(string $path): void
{
    header('Location: ' . BASE_URL . $path);
    exit;
}

/**
 * Check whether a user is currently logged in.
 */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id'], $_SESSION['role']);
}

/**
 * Require the user to be logged in. Redirects to login if not.
 */
function requireLogin(): void
{
    if (!isLoggedIn()) {
        redirect('pages/login.php');
    }
}

/**
 * Require the user to have one of the given roles.
 * Sends a 403 response and stops execution if unauthorized.
 *
 * @param string|array $allowedRoles  Single role string or array of roles.
 */
function requireRole(string|array $allowedRoles): void
{
    requireLogin();

    if (is_string($allowedRoles)) {
        $allowedRoles = [$allowedRoles];
    }

    if (!in_array($_SESSION['role'], $allowedRoles, true)) {
        http_response_code(403);
        echo '<!DOCTYPE html><html><head><title>Access Denied</title></head><body>';
        echo '<h1>403 — Access Denied</h1>';
        echo '<p>You do not have permission to access this page.</p>';
        echo '<a href="' . BASE_URL . '">Return to Home</a>';
        echo '</body></html>';
        exit;
    }
}

/**
 * Get the current user's session data.
 */
function currentUser(): array
{
    return [
        'user_id'   => $_SESSION['user_id']   ?? null,
        'username'  => $_SESSION['username']   ?? '',
        'full_name' => $_SESSION['full_name']  ?? '',
        'role'      => $_SESSION['role']       ?? '',
    ];
}

/**
 * Utility: write an entry to the audit_logs table.
 */
function writeAuditLog(PDO $pdo, int $userId, ?int $orderId, string $action, ?string $prevStatus = null, ?string $newStatus = null, ?string $details = null): void
{
    $stmt = $pdo->prepare(
        'INSERT INTO audit_logs (UserID, OrderID, ActionType, PreviousStatus, NewStatus, Details)
         VALUES (:uid, :oid, :action, :prev, :new, :details)'
    );
    $stmt->execute([
        ':uid'     => $userId,
        ':oid'     => $orderId,
        ':action'  => $action,
        ':prev'    => $prevStatus,
        ':new'     => $newStatus,
        ':details' => $details,
    ]);
}

/**
 * Generate a unique order number.
 * Format: KHL-YYYYMMDD-XXXX (sequential per day).
 */
function generateOrderNumber(PDO $pdo): string
{
    $today = date('Ymd');
    $prefix = 'KHL-' . $today . '-';

    $stmt = $pdo->prepare(
        "SELECT OrderNumber FROM orders
         WHERE OrderNumber LIKE :prefix
         ORDER BY OrderID DESC LIMIT 1"
    );
    $stmt->execute([':prefix' => $prefix . '%']);
    $last = $stmt->fetchColumn();

    if ($last) {
        $seq = (int) substr($last, -4) + 1;
    } else {
        $seq = 1;
    }

    return $prefix . str_pad($seq, 4, '0', STR_PAD_LEFT);
}
