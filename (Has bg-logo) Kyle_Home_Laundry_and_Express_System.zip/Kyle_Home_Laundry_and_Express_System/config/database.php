<?php
/**
 * Database Connection Configuration
 * Kyle Home Laundry and Express System
 *
 * Uses PDO with prepared statements for SQL injection prevention.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'kyle_laundry');
define('DB_USER', 'root');
define('DB_PASS', '');          // Default XAMPP — no password
define('DB_CHARSET', 'utf8mb4');

/**
 * Get a PDO database connection.
 * Returns the same instance on repeated calls (singleton pattern).
 */
function getDBConnection(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Do not expose connection details to end users
            error_log('Database connection failed: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Database connection error. Please try again later.']);
            exit;
        }
    }

    return $pdo;
}
