<?php
/**
 * Global Constants
 * Kyle Home Laundry and Express System
 */

// ── Application ──────────────────────────────────────────────
define('APP_NAME', 'Kyle Home Laundry & Express');
define('APP_VERSION', '1.0.0');

// ── Base URL (adjust if project is inside a subfolder) ───────
// For XAMPP: http://localhost/Kyle_Home_Laundry_and_Express_System/
define('BASE_URL', '/');

// ── User Roles ───────────────────────────────────────────────
define('ROLE_FRONT_DESK',    'front_desk');
define('ROLE_WASHER_FOLDER', 'washer_folder');
define('ROLE_DRIVER',        'driver');
define('ROLE_MANAGER',       'manager');

// ── Order Statuses (matches ENUM in `orders` table) ──────────
define('STATUS_PENDING',              'Pending');
define('STATUS_WASHING',              'Washing');
define('STATUS_DRYING',               'Drying');
define('STATUS_FOLDING_AND_PACKING',  'Folding and Packing');
define('STATUS_READY',                'Ready');
define('STATUS_OUT_FOR_DELIVERY',     'Out for Delivery');
define('STATUS_PICKED_UP',            'Picked Up');
define('STATUS_DELIVERED',            'Delivered');

// Ordered status progression for Kanban columns
define('STATUS_ORDER', [
    STATUS_PENDING,
    STATUS_WASHING,
    STATUS_DRYING,
    STATUS_FOLDING_AND_PACKING,
    STATUS_READY,
]);

// Terminal / completed statuses
define('COMPLETED_STATUSES', [
    STATUS_PICKED_UP,
    STATUS_DELIVERED,
]);

// ── Fixed Service Rates (₱) — from Approved Proposal ────────
define('RATE_WASH', 50.00);
define('RATE_DRY',  80.00);
define('RATE_FOLD', 20.00);

// ── Session lifetime (seconds) ──────────────────────────────
define('SESSION_LIFETIME', 3600); // 1 hour

// ── Role → Default landing page mapping ─────────────────────
define('ROLE_LANDING', [
    ROLE_FRONT_DESK    => 'pages/front-desk/order_queue.php',
    ROLE_WASHER_FOLDER => 'pages/washer/kanban.php',
    ROLE_DRIVER        => 'pages/driver/delivery_list.php',
    ROLE_MANAGER       => 'pages/manager/financial_summary.php',
]);
