-- ============================================================
-- Kyle Home Laundry and Express System — Database Schema
-- MySQL 5.7+ / MariaDB 10.3+
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+08:00";

-- Create and use the database
CREATE DATABASE IF NOT EXISTS `kyle_laundry` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `kyle_laundry`;

-- ============================================================
-- 1. USERS — system operators (Front Desk, Washer/Folder, Driver, Manager)
-- ============================================================
CREATE TABLE `users` (
  `UserID`       INT          NOT NULL AUTO_INCREMENT,
  `FullName`     VARCHAR(120) NOT NULL,
  `Username`     VARCHAR(60)  NOT NULL,
  `PasswordHash` VARCHAR(255) NOT NULL,
  `Role`         ENUM('front_desk','washer_folder','driver','manager') NOT NULL,
  `IsActive`     TINYINT(1)   NOT NULL DEFAULT 1,
  `CreatedAt`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `uq_username` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 2. CUSTOMERS — walk-in / delivery customers
-- ============================================================
CREATE TABLE `customers` (
  `CustomerID`    INT          NOT NULL AUTO_INCREMENT,
  `FullName`      VARCHAR(120) NOT NULL,
  `ContactNumber` VARCHAR(20)  DEFAULT NULL,
  `CreatedAt`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CustomerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 3. SERVICE_TYPES — fixed-rate services (Wash, Dry, Fold)
-- ============================================================
CREATE TABLE `service_types` (
  `ServiceTypeID` INT            NOT NULL AUTO_INCREMENT,
  `ServiceName`   VARCHAR(50)    NOT NULL,
  `Rate`          DECIMAL(10,2)  NOT NULL,
  PRIMARY KEY (`ServiceTypeID`),
  UNIQUE KEY `uq_service_name` (`ServiceName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 4. ORDERS — the main transaction table
-- ============================================================
CREATE TABLE `orders` (
  `OrderID`             INT            NOT NULL AUTO_INCREMENT,
  `OrderNumber`         VARCHAR(20)    NOT NULL,
  `CustomerID`          INT            NOT NULL,
  `ReceivedAt`          DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `WeightKg`            DECIMAL(6,2)   NOT NULL DEFAULT 0.00,
  `TotalAmount`         DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
  `Status`              ENUM('Pending','Washing','Drying','Folding and Packing','Ready','Out for Delivery','Picked Up','Delivered') NOT NULL DEFAULT 'Pending',
  `MachineNumber`       VARCHAR(20)    DEFAULT NULL,
  `IsDelivery`          TINYINT(1)     NOT NULL DEFAULT 0,
  `CreatedByUserID`     INT            NOT NULL,
  `LastUpdatedByUserID` INT            DEFAULT NULL,
  `LastUpdatedAt`       DATETIME       DEFAULT NULL,
  `CompletedAt`         DATETIME       DEFAULT NULL,
  PRIMARY KEY (`OrderID`),
  UNIQUE KEY `uq_order_number` (`OrderNumber`),
  KEY `idx_status` (`Status`),
  KEY `idx_customer` (`CustomerID`),
  KEY `idx_created_by` (`CreatedByUserID`),
  CONSTRAINT `fk_order_customer`   FOREIGN KEY (`CustomerID`)          REFERENCES `customers` (`CustomerID`),
  CONSTRAINT `fk_order_created_by` FOREIGN KEY (`CreatedByUserID`)     REFERENCES `users` (`UserID`),
  CONSTRAINT `fk_order_updated_by` FOREIGN KEY (`LastUpdatedByUserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 5. ORDER_SERVICE_LINES — line items per order
-- ============================================================
CREATE TABLE `order_service_lines` (
  `LineID`        INT           NOT NULL AUTO_INCREMENT,
  `OrderID`       INT           NOT NULL,
  `ServiceTypeID` INT           NOT NULL,
  `Quantity`      INT           NOT NULL DEFAULT 1,
  `LineSubtotal`  DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`LineID`),
  KEY `idx_order` (`OrderID`),
  CONSTRAINT `fk_line_order`   FOREIGN KEY (`OrderID`)       REFERENCES `orders` (`OrderID`) ON DELETE CASCADE,
  CONSTRAINT `fk_line_service` FOREIGN KEY (`ServiceTypeID`) REFERENCES `service_types` (`ServiceTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 6. DELIVERY_ASSIGNMENTS — express delivery tracking
-- ============================================================
CREATE TABLE `delivery_assignments` (
  `DeliveryID`      INT          NOT NULL AUTO_INCREMENT,
  `OrderID`         INT          NOT NULL,
  `DeliveryAddress` VARCHAR(255) NOT NULL,
  `ContactNumber`   VARCHAR(20)  NOT NULL,
  `DriverUserID`    INT          DEFAULT NULL,
  `AssignedAt`      DATETIME     DEFAULT NULL,
  `DeliveryStatus`  ENUM('Unassigned','Assigned','Out for Delivery','Delivered') NOT NULL DEFAULT 'Unassigned',
  `DeliveredAt`     DATETIME     DEFAULT NULL,
  PRIMARY KEY (`DeliveryID`),
  UNIQUE KEY `uq_delivery_order` (`OrderID`),
  KEY `idx_driver` (`DriverUserID`),
  CONSTRAINT `fk_delivery_order`  FOREIGN KEY (`OrderID`)     REFERENCES `orders` (`OrderID`) ON DELETE CASCADE,
  CONSTRAINT `fk_delivery_driver` FOREIGN KEY (`DriverUserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 7. AUDIT_LOGS — append-only action history (no UPDATE/DELETE allowed by app)
-- ============================================================
CREATE TABLE `audit_logs` (
  `LogID`          INT          NOT NULL AUTO_INCREMENT,
  `UserID`         INT          NOT NULL,
  `OrderID`        INT          DEFAULT NULL,
  `ActionType`     VARCHAR(60)  NOT NULL,
  `PreviousStatus` VARCHAR(60)  DEFAULT NULL,
  `NewStatus`      VARCHAR(60)  DEFAULT NULL,
  `Details`        TEXT         DEFAULT NULL,
  `Timestamp`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`LogID`),
  KEY `idx_audit_user`  (`UserID`),
  KEY `idx_audit_order` (`OrderID`),
  KEY `idx_audit_time`  (`Timestamp`),
  CONSTRAINT `fk_audit_user`  FOREIGN KEY (`UserID`)  REFERENCES `users` (`UserID`),
  CONSTRAINT `fk_audit_order` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Fixed service rates (Approved Proposal)
INSERT INTO `service_types` (`ServiceName`, `Rate`) VALUES
  ('Wash', 50.00),
  ('Dry',  80.00),
  ('Fold', 20.00);

-- Test users (password for all: "password123")
-- Hash generated by PHP password_hash('password123', PASSWORD_DEFAULT)
INSERT INTO `users` (`FullName`, `Username`, `PasswordHash`, `Role`) VALUES
  ('Maria Santos',   'front_desk1', '$2y$10$8KzQbLx3k6e3F0v3GSQOO.0jS6X5mCq8kN0VdMnL9MzBnVw6p5HfK', 'front_desk'),
  ('Juan Dela Cruz', 'washer1',     '$2y$10$8KzQbLx3k6e3F0v3GSQOO.0jS6X5mCq8kN0VdMnL9MzBnVw6p5HfK', 'washer_folder'),
  ('Pedro Reyes',    'driver1',     '$2y$10$8KzQbLx3k6e3F0v3GSQOO.0jS6X5mCq8kN0VdMnL9MzBnVw6p5HfK', 'driver'),
  ('Kyle Manager',   'manager1',    '$2y$10$8KzQbLx3k6e3F0v3GSQOO.0jS6X5mCq8kN0VdMnL9MzBnVw6p5HfK', 'manager');

COMMIT;
