<?php
/**
 * Database Setup Helper
 * Kyle Home Laundry and Express System
 *
 * Run this script ONCE after importing kyle_laundry.sql to generate
 * proper bcrypt password hashes for the seed users.
 *
 * Usage: Open in browser via XAMPP: http://localhost/Kyle_Home_Laundry_and_Express_System/database/setup.php
 */

require_once __DIR__ . '/../config/database.php';

$defaultPassword = 'password123';
$hash = password_hash($defaultPassword, PASSWORD_DEFAULT);

try {
    $pdo = getDBConnection();

    // Update all seed users with a proper bcrypt hash
    $stmt = $pdo->prepare("UPDATE users SET PasswordHash = :hash WHERE PasswordHash NOT LIKE '$2y$%'");
    $affected = $stmt->execute([':hash' => $hash]);

    // Also update any users whose hash doesn't actually verify
    $users = $pdo->query("SELECT UserID, PasswordHash FROM users")->fetchAll();
    $updated = 0;
    foreach ($users as $user) {
        if (!password_verify($defaultPassword, $user['PasswordHash'])) {
            $stmt = $pdo->prepare("UPDATE users SET PasswordHash = :hash WHERE UserID = :id");
            $stmt->execute([':hash' => $hash, ':id' => $user['UserID']]);
            $updated++;
        }
    }

    echo "<h2>✅ Database Setup Complete</h2>";
    echo "<p>Password hash generated and applied to all seed users.</p>";
    echo "<p>Updated <strong>{$updated}</strong> user(s).</p>";
    echo "<p>Default password for all test users: <code>{$defaultPassword}</code></p>";
    echo "<hr>";
    echo "<h3>Test Accounts:</h3>";
    echo "<table border='1' cellpadding='8' cellspacing='0'>";
    echo "<tr><th>Username</th><th>Role</th><th>Password</th></tr>";

    $users = $pdo->query("SELECT Username, Role FROM users ORDER BY UserID")->fetchAll();
    foreach ($users as $u) {
        echo "<tr><td>{$u['Username']}</td><td>{$u['Role']}</td><td>{$defaultPassword}</td></tr>";
    }
    echo "</table>";
    echo "<br><a href='../pages/login.php'>→ Go to Login Page</a>";

} catch (Exception $e) {
    echo "<h2>❌ Error</h2>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Make sure you have imported <code>kyle_laundry.sql</code> into MySQL first.</p>";
}
