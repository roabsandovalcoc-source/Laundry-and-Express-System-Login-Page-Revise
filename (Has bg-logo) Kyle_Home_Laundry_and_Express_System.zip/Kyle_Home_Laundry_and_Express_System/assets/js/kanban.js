document.addEventListener('DOMContentLoaded', () => {
    loadKanban();

    // Modal close handlers
    const machineModal = document.getElementById('machineModal');
    const closeModal = () => { machineModal.classList.remove('active'); };
    document.getElementById('closeMachineModal').addEventListener('click', closeModal);
    document.getElementById('cancelMachineModal').addEventListener('click', closeModal);
    machineModal.addEventListener('click', (e) => {
        if (e.target === machineModal) closeModal();
    });
});

let currentMoveAction = null;

function loadKanban() {
    fetch(`${KANBAN_API_URL}?action=get_kanban`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                renderKanban(data.data);
            } else {
                showAlert(data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('Failed to load kanban board', 'danger');
        });
}

function renderKanban(boardData) {
    const board = document.getElementById('kanbanBoard');
    board.innerHTML = '';

    const columns = [
        { id: 'Pending', title: 'Pending', next: 'Washing', class: 'pending' },
        { id: 'Washing', title: 'Washing', next: 'Drying', class: 'washing' },
        { id: 'Drying', title: 'Drying', next: 'Folding and Packing', class: 'drying' },
        { id: 'Folding and Packing', title: 'Folding & Packing', next: 'Ready', class: 'folding' },
        { id: 'Ready', title: 'Ready', next: null, class: 'ready' }
    ];

    columns.forEach(col => {
        const items = boardData[col.id] || [];
        
        const colDiv = document.createElement('div');
        colDiv.className = 'kanban-column';
        
        const headerDiv = document.createElement('div');
        headerDiv.className = `kanban-header ${col.class}`;
        headerDiv.innerHTML = `<span>${col.title}</span> <span class="badge">${items.length}</span>`;
        colDiv.appendChild(headerDiv);
        
        const cardsDiv = document.createElement('div');
        cardsDiv.className = 'kanban-cards';
        
        items.forEach(order => {
            const card = document.createElement('div');
            card.className = `kanban-card ${col.class}`;
            card.onclick = (e) => {
                if(e.target.tagName !== 'BUTTON') {
                    window.location.href = `${ORDER_DETAILS_URL}${order.OrderID}`;
                }
            };
            
            const timeSince = getTimeSince(new Date(order.ReceivedAt));
            
            card.innerHTML = `
                <h4>#${order.OrderNumber}</h4>
                <p><strong>${order.CustomerName}</strong></p>
                <p>Weight: ${order.WeightKg} kg</p>
                <p>Services: ${order.Services}</p>
                <div class="time">Received: ${timeSince}</div>
            `;
            
            if (col.next) {
                const btn = document.createElement('button');
                btn.className = 'kanban-btn';
                btn.textContent = `Move to ${col.next}`;
                btn.onclick = (e) => {
                    e.stopPropagation();
                    initiateMove(order.OrderID, col.next);
                };
                card.appendChild(btn);
            }
            
            cardsDiv.appendChild(card);
        });
        
        colDiv.appendChild(cardsDiv);
        board.appendChild(colDiv);
    });
}

function getTimeSince(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + " years ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + " months ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + " days ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + " hours ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + " minutes ago";
    return Math.floor(seconds) + " seconds ago";
}

function initiateMove(orderId, nextStatus) {
    if (nextStatus === 'Washing' || nextStatus === 'Drying') {
        currentMoveAction = { orderId, nextStatus };
        document.getElementById('machineNumberInput').value = '';
        document.getElementById('machineModal').classList.add('active');
    } else {
        updateStatus(orderId, nextStatus, null);
    }
}

document.getElementById('submitMachineNumber').addEventListener('click', () => {
    const machineNo = document.getElementById('machineNumberInput').value;
    if (!machineNo) {
        alert('Please enter a machine number');
        return;
    }
    
    document.getElementById('machineModal').classList.remove('active');
    if (currentMoveAction) {
        updateStatus(currentMoveAction.orderId, currentMoveAction.nextStatus, machineNo);
        currentMoveAction = null;
    }
});

function updateStatus(orderId, newStatus, machineNumber) {
    const formData = new FormData();
    formData.append('order_id', orderId);
    formData.append('new_status', newStatus);
    if (machineNumber) {
        formData.append('machine_number', machineNumber);
    }

    fetch(`${KANBAN_API_URL}?action=update_status`, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert(`Order moved to ${newStatus}`, 'success');
            loadKanban();
        } else {
            showAlert(data.message || 'Failed to update status', 'danger');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('Error updating status', 'danger');
    });
}
