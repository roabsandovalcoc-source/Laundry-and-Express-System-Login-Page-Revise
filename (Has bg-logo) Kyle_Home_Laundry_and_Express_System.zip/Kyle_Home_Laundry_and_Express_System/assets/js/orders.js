document.addEventListener('DOMContentLoaded', function() {
    
    // Order Queue: Search and Filter
    const orderSearch = document.getElementById('orderSearch');
    const statusFilter = document.getElementById('statusFilter');
    const ordersTable = document.getElementById('ordersTable');

    if (orderSearch && statusFilter && ordersTable) {
        function filterTable() {
            const searchTerm = orderSearch.value.toLowerCase();
            const statusValue = statusFilter.value;
            const rows = ordersTable.querySelectorAll('tbody tr');

            rows.forEach(row => {
                const orderNum = row.querySelector('.order-number').textContent.toLowerCase();
                const custName = row.querySelector('.customer-name').textContent.toLowerCase();
                const rowStatus = row.getAttribute('data-status');

                const matchesSearch = orderNum.includes(searchTerm) || custName.includes(searchTerm);
                const matchesStatus = statusValue === '' || rowStatus === statusValue;

                if (matchesSearch && matchesStatus) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        orderSearch.addEventListener('input', filterTable);
        statusFilter.addEventListener('change', filterTable);
    }

    // New Order Form Logic
    const newOrderForm = document.getElementById('newOrderForm');
    if (newOrderForm) {
        const isDelivery = document.getElementById('isDelivery');
        const deliveryFields = document.getElementById('deliveryFields');
        const deliveryAddress = document.getElementById('deliveryAddress');
        const deliveryContact = document.getElementById('deliveryContact');
        const totalAmountDisplay = document.getElementById('totalAmountDisplay');
        const serviceCheckboxes = document.querySelectorAll('.service-checkbox');

        // Toggle Delivery Fields
        isDelivery.addEventListener('change', function() {
            if (this.checked) {
                deliveryFields.style.display = 'block';
                deliveryAddress.required = true;
                deliveryContact.required = true;
            } else {
                deliveryFields.style.display = 'none';
                deliveryAddress.required = false;
                deliveryContact.required = false;
            }
        });

        // Calculate Totals
        function calculateTotal() {
            let total = 0;
            serviceCheckboxes.forEach(cb => {
                const qtyInput = cb.closest('.service-row').querySelector('.service-qty');
                const subtotalDisplay = cb.closest('.service-row').querySelector('.service-subtotal');
                const rate = parseFloat(cb.dataset.rate);
                
                if (cb.checked) {
                    qtyInput.disabled = false;
                    if (!qtyInput.value) qtyInput.value = 1;
                    const qty = parseInt(qtyInput.value) || 0;
                    const subtotal = rate * qty;
                    total += subtotal;
                    subtotalDisplay.textContent = '₱' + subtotal.toFixed(2);
                } else {
                    qtyInput.disabled = true;
                    qtyInput.value = '';
                    subtotalDisplay.textContent = '₱0.00';
                }
            });
            totalAmountDisplay.textContent = '₱' + total.toFixed(2);
            return total;
        }

        serviceCheckboxes.forEach(cb => {
            cb.addEventListener('change', calculateTotal);
            const qtyInput = cb.closest('.service-row').querySelector('.service-qty');
            qtyInput.addEventListener('input', calculateTotal);
        });

        // Form Submit
        newOrderForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(newOrderForm);
            const totalAmount = calculateTotal();
            
            const payload = {
                customerName: formData.get('customerName'),
                contactNumber: formData.get('contactNumber'),
                weightKg: formData.get('weightKg'),
                isDelivery: formData.get('isDelivery') === '1',
                deliveryAddress: formData.get('deliveryAddress'),
                deliveryContact: formData.get('deliveryContact'),
                totalAmount: totalAmount,
                services: []
            };

            let hasServices = false;
            serviceCheckboxes.forEach(cb => {
                if (cb.checked) {
                    hasServices = true;
                    const sid = cb.id.replace('service_', '');
                    const qtyInput = cb.closest('.service-row').querySelector('.service-qty');
                    const qty = parseInt(qtyInput.value) || 1;
                    const rate = parseFloat(cb.dataset.rate);
                    payload.services.push({
                        serviceTypeId: sid,
                        quantity: qty,
                        subtotal: rate * qty
                    });
                }
            });

            if (!hasServices) {
                if(typeof showAlert === 'function') showAlert('Please select at least one service.', 'warning');
                else alert('Please select at least one service.');
                return;
            }

            const btn = document.getElementById('submitOrderBtn');
            btn.disabled = true;
            btn.textContent = 'Processing...';

            fetch(BASE_URL + 'api/orders.php?action=create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if(typeof showAlert === 'function') showAlert('Order created successfully!', 'success');
                    else alert('Order created successfully!');
                    window.location.href = BASE_URL + 'pages/front-desk/order_queue.php';
                } else {
                    if(typeof showAlert === 'function') showAlert(data.message || 'Error creating order.', 'danger');
                    else alert(data.message || 'Error creating order.');
                    btn.disabled = false;
                    btn.textContent = 'Create Order';
                }
            })
            .catch(err => {
                console.error(err);
                if(typeof showAlert === 'function') showAlert('A network error occurred.', 'danger');
                else alert('A network error occurred.');
                btn.disabled = false;
                btn.textContent = 'Create Order';
            });
        });
    }

    // Order Details logic
    const btnMarkPickedUp = document.getElementById('btnMarkPickedUp');
    if (btnMarkPickedUp) {
        btnMarkPickedUp.addEventListener('click', function() {
            if (!confirm('Are you sure you want to mark this order as Picked Up?')) return;
            
            const orderId = this.dataset.id;
            fetch(BASE_URL + 'api/orders.php?action=pickup', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ orderId: orderId })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Error updating order');
                }
            });
        });
    }

    // Driver Assignment Modal — custom modal (no Bootstrap)
    const btnAssignDriver = document.getElementById('btnAssignDriver');
    const assignModal = document.getElementById('assignDriverModal');

    if (btnAssignDriver && assignModal) {
        // Open modal and load drivers
        btnAssignDriver.addEventListener('click', function() {
            assignModal.classList.add('active');
            const select = document.getElementById('driverSelect');
            select.innerHTML = '<option value="">Loading drivers...</option>';

            fetch(BASE_URL + 'api/orders.php?action=get_drivers')
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        select.innerHTML = '<option value="">Select a driver...</option>';
                        data.drivers.forEach(d => {
                            select.innerHTML += `<option value="${d.UserID}">${d.FullName}</option>`;
                        });
                    } else {
                        select.innerHTML = '<option value="">Error loading drivers</option>';
                    }
                });
        });

        // Close modal handlers
        const closeModal = function() { assignModal.classList.remove('active'); };
        document.getElementById('closeDriverModal').addEventListener('click', closeModal);
        document.getElementById('cancelDriverModal').addEventListener('click', closeModal);
        assignModal.addEventListener('click', function(e) {
            if (e.target === assignModal) closeModal();
        });

        // Submit assignment
        const submitDriverAssignment = document.getElementById('submitDriverAssignment');
        submitDriverAssignment.addEventListener('click', function() {
            const driverId = document.getElementById('driverSelect').value;
            const orderId = document.getElementById('modalOrderId').value;

            if (!driverId) {
                alert('Please select a driver');
                return;
            }

            submitDriverAssignment.disabled = true;
            submitDriverAssignment.textContent = 'Assigning...';

            fetch(BASE_URL + 'api/orders.php?action=assign_driver', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ orderId: orderId, driverId: driverId })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Error assigning driver');
                    submitDriverAssignment.disabled = false;
                    submitDriverAssignment.textContent = 'Assign';
                }
            });
        });
    }
});
