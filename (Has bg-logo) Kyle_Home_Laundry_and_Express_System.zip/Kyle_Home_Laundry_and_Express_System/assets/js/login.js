document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const loginBtn = document.getElementById('loginBtn');
    const loginSpinner = document.getElementById('loginSpinner');
    const loginAlert = document.getElementById('loginAlert');
    const btnText = loginBtn.querySelector('.btn-text');

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const username = loginForm.username.value.trim();
            const password = loginForm.password.value;

            // Basic client-side validation
            if (!username || !password) {
                showAlert('Please enter both username and password.', 'danger');
                return;
            }

            // Show loading state
            setLoading(true);

            try {
                const formData = new FormData(loginForm);
                const response = await fetch(`${BASE_URL}api/auth.php?action=login`, {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.success) {
                    showAlert('Login successful! Redirecting...', 'success');
                    setTimeout(() => {
                        window.location.href = data.redirect;
                    }, 500);
                } else {
                    showAlert(data.message || 'Login failed. Please check your credentials.', 'danger');
                    setLoading(false);
                }
            } catch (error) {
                console.error('Login error:', error);
                showAlert('An error occurred during login. Please try again.', 'danger');
                setLoading(false);
            }
        });
    }

    function setLoading(isLoading) {
        if (isLoading) {
            loginBtn.disabled = true;
            loginSpinner.classList.remove('hidden');
            btnText.textContent = 'Logging in...';
        } else {
            loginBtn.disabled = false;
            loginSpinner.classList.add('hidden');
            btnText.textContent = 'Log In';
        }
    }

    function showAlert(message, type) {
        loginAlert.textContent = message;
        loginAlert.className = `alert alert-${type}`;
        loginAlert.classList.remove('hidden');
    }
});
