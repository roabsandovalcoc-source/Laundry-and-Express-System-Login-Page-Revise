document.addEventListener('DOMContentLoaded', () => {
    // Tab switching
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            btn.classList.add('active');
            const target = btn.getAttribute('data-target');
            document.getElementById(target).classList.add('active');
        });
    });

    // Mark as delivered
    const btnMarkDelivered = document.getElementById('btn-mark-delivered');
    if (btnMarkDelivered) {
        btnMarkDelivered.addEventListener('click', (e) => {
            const deliveryId = e.target.getAttribute('data-id');
            if (confirm('Are you sure you want to mark this delivery as completed?')) {
                const originalText = e.target.innerText;
                e.target.innerText = 'Processing...';
                e.target.disabled = true;

                const formData = new FormData();
                formData.append('id', deliveryId);

                fetch('../../api/delivery.php?action=mark_delivered', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (typeof showAlert === 'function') {
                            showAlert('success', data.message);
                        } else {
                            alert(data.message);
                        }
                        setTimeout(() => {
                            window.location.href = 'delivery_list.php';
                        }, 1000);
                    } else {
                        if (typeof showAlert === 'function') {
                            showAlert('error', data.message || 'Error occurred');
                        } else {
                            alert(data.message || 'Error occurred');
                        }
                        e.target.innerText = originalText;
                        e.target.disabled = false;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    e.target.innerText = originalText;
                    e.target.disabled = false;
                });
            }
        });
    }

    // Accept Delivery
    const btnAcceptDelivery = document.getElementById('btn-accept-delivery');
    if (btnAcceptDelivery) {
        btnAcceptDelivery.addEventListener('click', (e) => {
            const deliveryId = e.target.getAttribute('data-id');
            if (confirm('Are you sure you want to accept this delivery?')) {
                const originalText = e.target.innerText;
                e.target.innerText = 'Accepting...';
                e.target.disabled = true;

                const formData = new FormData();
                formData.append('id', deliveryId);

                fetch('../../api/delivery.php?action=accept_delivery', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (typeof showAlert === 'function') {
                            showAlert('success', data.message);
                        } else {
                            alert(data.message);
                        }
                        setTimeout(() => {
                            window.location.href = 'delivery_list.php';
                        }, 1000);
                    } else {
                        if (typeof showAlert === 'function') {
                            showAlert('error', data.message || 'Error occurred');
                        } else {
                            alert(data.message || 'Error occurred');
                        }
                        e.target.innerText = originalText;
                        e.target.disabled = false;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    e.target.innerText = originalText;
                    e.target.disabled = false;
                });
            }
        });
    }
});
