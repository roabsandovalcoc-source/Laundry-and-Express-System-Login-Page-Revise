/**
 * Kyle Home Laundry and Express System — Global JavaScript
 *
 * Provides: mobile nav toggle, alert auto-dismiss, utility helpers.
 */

document.addEventListener('DOMContentLoaded', function () {

    // ── Mobile Navbar Toggle ────────────────────────────────
    const toggle = document.getElementById('navbarToggle');
    const menu   = document.getElementById('navbarMenu');
    const userSection = document.querySelector('.navbar-user');

    if (toggle) {
        toggle.addEventListener('click', function () {
            menu.classList.toggle('open');
            if (userSection) userSection.classList.toggle('open');
        });
    }

    // ── Auto-dismiss alerts after 5 seconds ─────────────────
    document.querySelectorAll('.alert[data-auto-dismiss]').forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity 0.4s ease';
            alert.style.opacity = '0';
            setTimeout(function () { alert.remove(); }, 400);
        }, 5000);
    });

    // ── Active nav link highlighting ────────────────────────
    const currentPath = window.location.pathname;
    document.querySelectorAll('.nav-link').forEach(function (link) {
        if (currentPath.includes(link.getAttribute('href'))) {
            link.classList.add('active');
        }
    });
});

/**
 * Show a temporary toast-like alert at the top of the page.
 * @param {string} message - The message to show.
 * @param {string} type    - 'success' | 'danger' | 'warning' | 'info'
 */
function showAlert(message, type) {
    type = type || 'info';
    const container = document.querySelector('.main-content');
    if (!container) return;

    const alert = document.createElement('div');
    alert.className = 'alert alert-' + type;
    alert.setAttribute('data-auto-dismiss', 'true');
    alert.textContent = message;

    container.insertBefore(alert, container.firstChild);

    setTimeout(function () {
        alert.style.transition = 'opacity 0.4s ease';
        alert.style.opacity = '0';
        setTimeout(function () { alert.remove(); }, 400);
    }, 5000);
}

/**
 * Format a number as Philippine Peso.
 * @param {number} amount
 * @returns {string}
 */
function formatPeso(amount) {
    return '₱' + parseFloat(amount).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * Map order status to CSS class for badges.
 * @param {string} status
 * @returns {string}
 */
function statusClass(status) {
    var map = {
        'Pending':              'status-pending',
        'Washing':              'status-washing',
        'Drying':               'status-drying',
        'Folding and Packing':  'status-folding',
        'Ready':                'status-ready',
        'Out for Delivery':     'status-out-for-delivery',
        'Picked Up':            'status-picked-up',
        'Delivered':            'status-delivered'
    };
    return map[status] || 'status-pending';
}

/**
 * Simple confirmation before destructive actions.
 * @param {string} message
 * @returns {boolean}
 */
function confirmAction(message) {
    return window.confirm(message || 'Are you sure?');
}
